-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Rossfoter pedido
-- -----------------------------------------------------

-- -----------------------------------------------------
--  Rossfoter pedido
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `pedido` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `pedido` ;

-- -----------------------------------------------------
-- Table `pedido`.`Cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pedido`.`Cliente` (
  `idCliente` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NOT NULL,
  `sobrenome` VARCHAR(45) NOT NULL,
  `data_nascimento` DATE NOT NULL,
  `rg` VARCHAR(45) NOT NULL,
  `cpf` VARCHAR(45) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `login` VARCHAR(45) NOT NULL,
  `senha` VARCHAR(8) NOT NULL,
  `nivel_usuario` ENUM('adm','cliente','cliente_fornecedor') NOT NULL,
  PRIMARY KEY (`idCliente`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `pedido`.`Endereco`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pedido`.`Endereco` (
  `rua` VARCHAR(100) NOT NULL,
  `numero` VARCHAR(10) NOT NULL,
  `bairro` VARCHAR(45) NOT NULL,
  `cidade` VARCHAR(45) NOT NULL,
  `estado` VARCHAR(45) NOT NULL,
  `cep` VARCHAR(9) NOT NULL,
  `Cliente_idCliente` INT NOT NULL,
  INDEX `fk_Endereco_Cliente1_idx` (`Cliente_idCliente` ASC),
  CONSTRAINT `fk_Endereco_Cliente1`
    FOREIGN KEY (`Cliente_idCliente`)
    REFERENCES `pedido`.`Cliente` (`idCliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `pedido`.`Produto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pedido`.`Produto` (
  `idProduto` INT NOT NULL AUTO_INCREMENT,
  `nome_produto` VARCHAR(45) NOT NULL,
  `descricao` VARCHAR(150) NOT NULL,
  `estoque` VARCHAR(45) NOT NULL,
  `preco` DOUBLE NOT NULL,
  `promocao` VARCHAR(45) NOT NULL,
  `custo` DOUBLE NOT NULL,
  `fornecedor` VARCHAR(100) NOT NULL,
  `foto` LONGBLOB NOT NULL,
  PRIMARY KEY (`idProduto`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `pedido`.`Pedido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pedido`.`Pedido` (
  `idPedido` INT NOT NULL,
  `Cliente_idCliente` INT NOT NULL,
  PRIMARY KEY (`idPedido`),
  INDEX `fk_Pedido_Cliente1_idx` (`Cliente_idCliente` ASC),
  CONSTRAINT `fk_Pedido_Cliente1`
    FOREIGN KEY (`Cliente_idCliente`)
    REFERENCES `pedido`.`Cliente` (`idCliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `pedido`.`item_pedido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pedido`.`item_pedido` (
  `Pedido_idPedido` INT NOT NULL,
  `Produto_idProduto` INT NOT NULL,
  `quantidade` INT NULL,
  PRIMARY KEY (`Pedido_idPedido`, `Produto_idProduto`),
  INDEX `fk_Pedido_has_Produto_Produto1_idx` (`Produto_idProduto` ASC),
  INDEX `fk_Pedido_has_Produto_Pedido1_idx` (`Pedido_idPedido` ASC),
  CONSTRAINT `fk_Pedido_has_Produto_Pedido1`
    FOREIGN KEY (`Pedido_idPedido`)
    REFERENCES `pedido`.`Pedido` (`idPedido`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Pedido_has_Produto_Produto1`
    FOREIGN KEY (`Produto_idProduto`)
    REFERENCES `pedido`.`Produto` (`idProduto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


SHOW TABLES;

SELECT * FROM cliente;

insert into cliente values(null,'simone', 'santos','1995-10-19','1111111','44444444','simone@santos','simone','123','adm');


select * from cliente;


insert into cliente values(null,'ana', 'santos','1988-02-09','1111111','44444444','ana@santos','ana','123','cliente');


insert into cliente values(null,'jose', 'santos','1988-10-09','1111111','44444444','jose@santos','maria','123','cliente_fornecedor');

select * from cliente;

select * from endereco;
insert into endereco values('da rosa','20','da floresta','porto seguro','bahia','45810-000',1);

select * from endereco;

select * from cliente;
select idCliente,nome, sobrenome, data_nascimento, rg, cpf,email,login,senha,nivel_usuario from Cliente 
            
   left  join Endereco on Endereco.Cliente_idCliente = Cliente.idCliente where login='simone' and senha='123';
   
   
   
   select idCliente,nome, sobrenome, data_nascimento, rg, cpf, email, login, senha, nivel_usuario, rua, numero, 
   bairro, cidade, estado, cep from Cliente left join Endereco on Endereco.Cliente_idCliente = Cliente.idCliente where login= 'cliente1' and senha='123';
   
   
   insert into Cliente(nome, sobrenome, data_nascimento, rg, cpf, email, login, senha,nivel_usuario) 
                values('nome1','sobre1','2017-12-10','123','456','teste@email','login1','1234','cliente_fornecedor');
                
                insert into Endereco(Cliente_idCliente, rua, numero, bairro, cidade, estado, cep) 
                values(LAST_INSERT_ID(),'das rosas','123','centro','porto seguro','bahia','45810-000');
                
                desc Endereco;
                
 select * from cliente;

insert into produto values(null,'Malbec', 'Malbec desodorante colonia, 100 ml', 
03, 18,15,15,'Perfumaria','') ;

insert into produto values(null,'Sabonete liquido', 'Sabonete liquido corpo e cabelo .', 
05, 20,15,15,'cuidados com o corpo','') ;

insert into produto values(null,'Sabonete em barra', 'sabonete em barra 2 unidades.', 
05, 20,15,15,'cuidados com o corpo','') ;

 select * from produto;
 
 insert into Cliente(nome, sobrenome, data_nascimento, rg, cpf, email, login, senha,nivel_usuario) 
                values('nome1','sobre1','2017-12-10','123','456','teste@email','login1','1234','cliente_fornecedor');

 insert into Cliente(nome, sobrenome, data_nascimento, rg, cpf, email, login, senha,nivel_usuario) 
                values('nome2','sobre2','2017-12-10','123','456','teste@email','login2','1234','cliente_fornecedor');

select idProduto,nome_produto descricao, estoque, preco, promocao, custo,fornecedor,foto from Produto;

