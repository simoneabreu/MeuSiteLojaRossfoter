-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22-Nov-2021 às 19:38
-- Versão do servidor: 10.5.12-MariaDB-cll-lve
-- versão do PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `u576255937_lojarossfoster`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `Cliente`
--

CREATE TABLE `Cliente` (
  `idCliente` int(11) NOT NULL,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sobrenome` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_nascimento` date NOT NULL,
  `rg` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel_usuario` enum('adm','cliente','cliente_fornecedor') COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `Cliente`
--

INSERT INTO `Cliente` (`idCliente`, `nome`, `sobrenome`, `data_nascimento`, `rg`, `cpf`, `email`, `login`, `senha`, `nivel_usuario`) VALUES
(1, 'ana', 'santos', '1988-02-09', '11111114', '44444444', 'ana@santos', 'ana', '123', 'cliente'),
(2, 'jose', 'santos', '1988-10-09', '11111112', '44444444', 'jose@santos', 'maria', '123', 'cliente_fornecedor'),
(3, 'nome XXX', 'sobre1', '2017-12-10', '123', '456', 'teste@email', 'login1', '1234', 'cliente_fornecedor'),
(4, 'nome2', 'sobre2', '2017-12-10', '123', '456', 'teste@email', 'login2', '1234', 'cliente_fornecedor'),
(5, 'simone', 'abreu', '2021-11-21', '333', '312312', '?1', '?2', '?3', ''),
(6, 'wilson', 'rocha', '2021-11-21', 'm2867013', '607.466.706', '?1', '?2', '?3', ''),
(7, 'Wilson', 'rocha', '2021-11-21', 'm2867013', '607.466.706', '?1', '?2', '?3', ''),
(8, 'Xpto', 'Silva', '2021-11-21', '333', '312312', '?1', '?2', '?3', ''),
(9, 'Fulano', 'Mendes', '2021-11-21', '333', '312312', '?1', '?2', '?3', ''),
(10, 'Fulano', 'Mendes', '2021-11-21', '333', '312312', '?1', '?2', '?3', ''),
(11, 'Ciclano', 'Jose', '2021-11-21', '333', '312312', '?1', '?2', '?3', ''),
(12, 'Ciclano', 'Jose', '2021-11-21', '333', '312312', '?1', '?2', '?3', ''),
(13, 'Antonio', 'Asilva', '2021-11-21', '11111112', '607.466.706', '?1', '?2', '?3', ''),
(14, 'Lúcia', 'Maria', '2021-11-21', '12323', '34234324', '?1', '?2', '?3', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `Endereco`
--

CREATE TABLE `Endereco` (
  `rua` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bairro` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cep` varchar(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Cliente_idCliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `Endereco`
--

INSERT INTO `Endereco` (`rua`, `numero`, `bairro`, `cidade`, `estado`, `cep`, `Cliente_idCliente`) VALUES
('da rosa', '20', 'da floresta', 'porto seguro', 'bahia', '45810-000', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `item_pedido`
--

CREATE TABLE `item_pedido` (
  `Pedido_idPedido` int(11) NOT NULL,
  `Produto_idProduto` int(11) NOT NULL,
  `quantidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `Pedido`
--

CREATE TABLE `Pedido` (
  `idPedido` int(11) NOT NULL,
  `Cliente_idCliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `Produto`
--

CREATE TABLE `Produto` (
  `idProduto` int(11) NOT NULL,
  `nome_produto` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preco` double NOT NULL,
  `custo` double NOT NULL,
  `fornecedor` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estoque` double NOT NULL,
  `promocao` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `Produto`
--

INSERT INTO `Produto` (`idProduto`, `nome_produto`, `descricao`, `preco`, `custo`, `fornecedor`, `foto`, `estoque`, `promocao`) VALUES
(1, 'Malbec', 'Malbec desodorante colonia, 100 ml', 33, 15, 'Perfumaria', 'xxx', 15, 5),
(2, 'Sabonete liquido', 'Sabonete liquido corpo e cabelo .', 20, 15, 'cuidados com o corpo', '', 0, 0),
(3, 'Sabonete em barra', 'sabonete em barra 2 unidades.', 20, 15, 'cuidados com o corpo', '', 0, 0),
(4, 'Coca Cola', 'Refri Coca COla', 12, 3, 'coca-cola do Brasil', 'ggg', 23, 5);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `Cliente`
--
ALTER TABLE `Cliente`
  ADD PRIMARY KEY (`idCliente`);

--
-- Índices para tabela `Endereco`
--
ALTER TABLE `Endereco`
  ADD KEY `fk_Endereco_Cliente1_idx` (`Cliente_idCliente`);

--
-- Índices para tabela `item_pedido`
--
ALTER TABLE `item_pedido`
  ADD PRIMARY KEY (`Pedido_idPedido`,`Produto_idProduto`),
  ADD KEY `fk_Pedido_has_Produto_Produto1_idx` (`Produto_idProduto`),
  ADD KEY `fk_Pedido_has_Produto_Pedido1_idx` (`Pedido_idPedido`);

--
-- Índices para tabela `Pedido`
--
ALTER TABLE `Pedido`
  ADD PRIMARY KEY (`idPedido`),
  ADD KEY `fk_Pedido_Cliente1_idx` (`Cliente_idCliente`);

--
-- Índices para tabela `Produto`
--
ALTER TABLE `Produto`
  ADD PRIMARY KEY (`idProduto`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `Cliente`
--
ALTER TABLE `Cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `Produto`
--
ALTER TABLE `Produto`
  MODIFY `idProduto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `Endereco`
--
ALTER TABLE `Endereco`
  ADD CONSTRAINT `fk_Endereco_Cliente1` FOREIGN KEY (`Cliente_idCliente`) REFERENCES `Cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `item_pedido`
--
ALTER TABLE `item_pedido`
  ADD CONSTRAINT `fk_Pedido_has_Produto_Pedido1` FOREIGN KEY (`Pedido_idPedido`) REFERENCES `Pedido` (`idPedido`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Pedido_has_Produto_Produto1` FOREIGN KEY (`Produto_idProduto`) REFERENCES `Produto` (`idProduto`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `Pedido`
--
ALTER TABLE `Pedido`
  ADD CONSTRAINT `fk_Pedido_Cliente1` FOREIGN KEY (`Cliente_idCliente`) REFERENCES `Cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
