
<html>
      <head>
      </head>
      <body>
            <div>
                  <h1>LOJA VIRTUAL ROSSFOTER</h1>
                  <p>
                        Bem-vindo cliente a nossa Loja Virtual Rossfoter
                  </p>
                  <p>
                       Voce poderá cadastrar e efetuar compras online!
                  </p>
                  <p>
                       Contato: E-mail: Rossfoter@gmail.com
                  </p>
            </div>
      </body>
</html>