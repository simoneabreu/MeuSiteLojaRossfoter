<?php
session_start();
$erro = 0;
$operacao = $_POST['operacao'];
$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$rg = $_POST['rg'];
$cpf = $_POST['cpf'];
if ($operacao == "incluindo") {
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "INSERT INTO Cliente (nome, sobrenome, rg, cpf, data_nascimento, email, login, senha, nivel_usuario) " . 
        "VALUES ('" . $nome . "', '" . $sobrenome . "', '" . $rg . "', '" . $cpf . "',now(),'?1','?2','?3','?4')";
    //echo $query;
    $result = $mysqli->query($query);
} else {
    $idCliente = $_POST['idCliente'];
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "UPDATE Cliente SET nome = '" . $nome . "', sobrenome = '" . $sobrenome . 
        "', rg = '" . $rg . "', cpf = '" . $cpf . "' WHERE idCliente = " . $idCliente;
    $result = $mysqli->query($query);
}

echo '<script>';
echo 'window.open("AdmCliente.php","JANELA_ADM_OPERACAO");';
echo '</script>';
//echo "<a href='AdmCliente.php' target='JANELA_ADM_OPERACAO'>Continuar</a>";
/*
$data_nascimento = $_POST['ano_nascimento'].'-'.$_POST['mes_nascimento'].'-'.$_POST['dia_nascimento'];
$rua = $_POST['rua'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$cep = $_POST['cep'];
$email = $_POST['email'];
$login = $_POST['login'];
$senha = $_POST['senha'];
$nivel = $_SESSION['nivel'];
$codigo = $_SESSION['cliente'];
*/
?>
