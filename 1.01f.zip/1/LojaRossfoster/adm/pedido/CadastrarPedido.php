<?
session_start();
$idPedido = $_GET["id"];
if ($idPedido) {
    $operacao = "editando";
    $mysqli = new mysqli('LOCALHOST', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "SELECT * FROM Pedido WHERE idPedido = " . $idPedido;
    $result = $mysqli->query($query);
    if (!$result) {
        $mysqli->close();
        die("Erro na seleção de dados");
    }
    $row = $result->fetch_assoc();
} else {
    $operacao = "incluindo";
    $row["nome"] = "";
    $row["sobrenome"] = "";
    $row["rg"] = "";
    $row["cpf"] = "";
}
?>
<html>
    <head>
        <title>Cadastro de Pedidos</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    </head>
    <body>
        <form action="SalvarPedido.php" method="post" target="JANELA_ADM_PEDIDO_OPERACAO">
            <!-- DADOS PESSOAIS-->
            <div class="container">
                <h1><? if ($operacao == "editando") echo "Alterando"; else echo "Inserindo" ?> Pedido</h1>
                <input type="hidden" name="operacao" id="operacao" value="<?= $operacao?>">
                <? 
                if ($operacao == "editando") {
                    echo '<input type="hidden" name="idPedido" id="idPedido" value="' . $idPedido . '">';
                }
                ?>
                <fieldset>
                    <legend>Dados Pessoais</legend>
                    <label for="nome">Nome: </label>
                    <input type="text" name="nome" id="nome" value="<?= $row["nome"]?>">
                    <label for="sobrenome">Sobrenome: </label>
                    <input type="text" name="sobrenome" id="sobrenome" value="<?= $row["sobrenome"]?>">
                    <p>
                        <label for="nascimento">Data nascimento: </label>
                        <input type="date" name="dia_nascimento" id="dia_nascimento" size="2" maxlength="2" value="dd">
                        <input type="month" name="mes_nascimento" id="mes_nascimento" size="2" maxlength="2" value="mm">
                        <input type="number" name="ano_nascimento" id="ano_nascimento" min="1998" max="2020">
                    </p>
                    <p>
                        <label for="rg">RG: </label>
                        <input type="text" name="rg" id="rg" value="<?= $row["rg"]?>" size="13" maxlength="13">
                    </p>
                    <p>
                        <label>CPF:</label>
                        <input type="text" name="cpf"  value="<?= $row["cpf"]?>" size="11" maxlength=11>
                    </p>
                </fieldset>
                <fieldset>
                    <legend>Endereço</legend>
                    <label for="rua">Rua, avenida, logradouro</label>
                    <input type="text" name="rua" id="rua">
                    <label for="numero">Nº</label>
                    <input type="text" name="numero" id="numero">
                    <p>
                        <label for="bairro">Bairro: </label>
                        <input type="text" name="bairro" id="bairro">
                    </p>
                    <label for="cidade">Cidade: </label>
                    <input type="text" name="cidade" id="cidade">
                    <label for="estado">Estado:</label>
                    <input type="text" name="estado" id="estado">
                    <label for="cep">CEP: </label>
                    <input type="text" name="cep" id="cep" size="8" maxlength="8">
                </fieldset>
                <fieldset>
                    <legend>Dados de Login</legend>
                    <p>
                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email">
                    </p>
                    <p>
                        <label for="imagem_perfil">Imagem de perfil:</label>
                        <input type="file" name="imagem_perfil" id="imagem_perfil">
                    </p>
                    <p>
                        <label for="login">Login de usuário: </label>
                        <input type="text" name="login" id="login" size="10" maxlength="10">
                    <p>
                        <label for="senha">Senha: </label>
                        <input type="password" name="senha" id="senha" size="8" maxlength="8">
                        <label for="confirma_senha">Confirme a senha: </label>
                        <input type="password" name="confirma_senha" id="confirma_senha">
                        <input type="checkbox" checked="checked"> Lembrar senha
                </fieldset>
                <br />
                <button type="submit" class="enviar">Salvar</button>
                <button type="cancelar" class="cancela">Cancelar</button>
                <?if ($operacao == "editando") echo '<button type="excluir" class="excluir">Excluir</button>';?>
            </div>
        </form>
    </body>
</html>
