<?
session_start();
$idItemPedido = $_GET["idItemPedido"];
if ($idItemPedido) {
    $operacao = "editando";
    $mysqli = new mysqli('LOCALHOST', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = 
        "SELECT i.idItemPedido, i.qtdProduto, p.nome_produto, p.preco " .
        "FROM ItemPedido i " .  
        "LEFT OUTER JOIN Produto p ON i.idProduto = p.idProduto " .  
        "WHERE idItemPedido = " . $idItemPedido;
    $result = $mysqli->query($query);
    if (!$result) {
        $mysqli->close();
        die("Erro na seleção de dados");
    }
    $row = $result->fetch_assoc();
} else {
    $operacao = "incluindo";
    $row["nome_produto"] = "";
}
?>
<html>
    <head>
        <title>Cadastro de Pedidos</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    </head>
    <body>
        <form action="SalvarItemPedido.php" method="post" target="JANELA_ADM_ITEMPEDIDO_OPERACAO">
            <!-- DADOS PESSOAIS-->
            <div class="container">
                <h1><? if ($operacao == "editando") echo "Alterando"; else echo "Inserindo" ?> Pedido</h1>
                <input type="hidden" name="operacao" id="operacao" value="<?= $operacao?>">
                <? 
                if ($operacao == "editando") {
                    echo '<input type="hidden" name="idItemPedido" id="idItemPedido" value="' . $idItemPedido . '">';
                }
                ?>
                <fieldset>
                    <legend>Produto</legend>
                    <label for="nome_produto">Produto: </label>
                    <input type="text" name="nome_produto" id="nome_produto" value="<?= $row["nome_produto"]?>"><br>
                    <label for="qtd_produto">Quantidade: </label>
                    <input type="text" name="qtd_produto" id="qtd_produto" value="<?= $row["qtdProduto"]?>"><br>
                    <label for="valor_produto">Preço: </label>
                    <input type="text" name="preco_produto" id="preco_produto" value="<?= $row["preco"]?>">
                </fieldset>
                <br />
                <button type="submit" class="enviar">Salvar</button>
                <button type="cancelar" class="cancela">Cancelar</button>
                <?if ($operacao == "editando") echo '<button type="excluir" class="excluir">Excluir</button>';?>
            </div>
        </form>
    </body>
</html>
