<? ?>
<html> 
     <body>
        <div>
            <a href='IncluirAdministrador.php' target="JANELA_ADM_ADMINISTRADOR_OPERACAO">
                <input type="button" value="Incluir">
            </a>
        <div>
    </body>
</html>
<? ?>
