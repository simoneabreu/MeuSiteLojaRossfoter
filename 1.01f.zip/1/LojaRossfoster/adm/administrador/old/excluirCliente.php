

<?php
//session_start();

//if(isset($_SESSION['usuario'])){
  //  $cpf = $_GET['cpf'];
    //if(isset($_SESSION['clientes'])){
        
      // foreach($_SESSION['clientes'] as $p=>$c){
          //  if($a['cpf']==$cpf){
              //  unset($_SESSION['clientes'][$p]);
             //   break;
          //  }
        //}
        
   // }
//}
//header('location: ../admin/index.php');
require_once '../modelo/Cliente.php';
require_once '../persistencia/ClienteDAO.php';
session_start();
if(isset($_SESSION['cliente'])){
    
    if($cliente->getNivel()== Cliente::ADMINISTRADOR ){
        $codigo = $_GET['codigo'];
        ClienteDAO::excluir($codigo);
    }
}
header('location: ../index.php');
?>

?>


