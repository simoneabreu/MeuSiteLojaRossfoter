<?php

//session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/modelo/cliente.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/persistencia/clienteDAO.php";

//$erro = 1;
//if(isset($_SESSION['usuario']) && 
//      $_SESSION['usuario'] == "clientes"){
//leitura dos dados do formulário
$nome = $_POST['nome']; //'nome' é o name do input
$sobrenome = $_POST['sobrenome'];
$data_nascimento = $_POST['ano_nascimento'].'-'.$_POST['mes_nascimento'].'-'.$_POST['dia_nascimento'];
$rg = $_POST['rg'];
$cpf = $_POST['cpf'];
//$endereco = $_POST['endereco'];
  $rua = $_POST['rua'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$cep = $_POST['cep'];
$email = $_POST['email'];
$login = $_POST['login'];
$senha = $_POST['senha'];
//$nivel -$_POST['nivel'];


$end = new Endereco($rua, $numero, $bairro, $cidade, $estado, $cep);
$c = new Cliente($nome, $sobrenome, $data_nascimento, $rg, $cpf, $end,
         $email, $login, $senha,'Cliente');
ClienteDAO::cadastrar($c);

//if($cliente->getNivel() ==  Cliente::ADMINISTRADOR){
  // header('location:../../auxiliares/administrador/index.php');
    //}
    //if ($cliente->getNivel()==  Cliente::CLIENTE){
      //header('location:../../auxiliares/cliente/index.php');  
    //}
    //if ($cliente->getNivel()==  Cliente::CLIENTE_FORNECEDOR){
      //header('location:../../auxiliares/clienteFornecedor/index.php');  
    //}
 //else {
  header("location: ../../index.php");      
//}

//if(!isset($_SESSION['clientes'])){
//    $_SESSION['clientes'] = array();
//}
// $_SESSION['clientes'][] = array("cpf"=>$cpf,"nome"=>$nome);
//header('location: ../../cliente/index.php');
//}
//else{
//  header('location: ../index.php');
//}
?>
