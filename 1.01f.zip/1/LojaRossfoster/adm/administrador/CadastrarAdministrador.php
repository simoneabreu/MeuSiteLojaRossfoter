<?
session_start();
$idAdmin = $_GET["idAdmin"];
if ($idAdmin) {
    $operacao = "editando";
    $mysqli = new mysqli('LOCALHOST', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "SELECT * FROM Admin WHERE idAdmin = " . $idAdmin;
    $result = $mysqli->query($query);
    if (!$result) {
        $mysqli->close();
        die("Erro na seleção de dados");
    }
    $row = $result->fetch_assoc();
} else {
    $operacao = "incluindo";
    $row["nome"]  = "";
    $row["login"] = "";
    $row["senha"] = "";
    $row["email"] = "";
}
?>
<html>
    <head>
        <title>Cadastro de Clientes</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    </head>
    <body>
        <form action="SalvarAdministrador.php" method="post" target="JANELA_ADM_ADMINISTRADOR_OPERACAO">
            <!-- DADOS PESSOAIS-->
            <div class="container">
                <h1><? if ($operacao == "editando") echo "Alterando"; else echo "Inserindo" ?> Administrador</h1>
                <input type="hidden" name="operacao" id="operacao" value="<?= $operacao?>">
                <? if ($operacao == "editando") echo '<input type="hidden" name="idAdmin" id="idAdmin" value="' . $idAdmin . '">'; ?>
                <fieldset>
                    <legend>Dados Pessoais</legend>
                    <label for="nome">Nome: </label>
                    <input type="text" name="nome" id="nome" value="<?= $row['nome']?>">
                </fieldset>
                <fieldset>
                    <legend>Dados de Login</legend>
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?= $row['email']?>"><br>
                        <label for="login">Login de usuário: </label>
                        <input type="text" id="login" name="login" size="10" maxlength="10" value="<?= $row['login']?>"><br>
                        <label for="senha">Senha: </label>
                        <input type="password" id="senha" name="senha" size="8" maxlength="8" value=""><br>
                        <label for="confirma_senha">Confirme a senha: </label>
                        <input type="password" id="confirma_senha" name="confirma_senha" value=""><br>
                </fieldset>
                <br />
                <button type="submit" class="enviar">Salvar</button>
                <button type="cancelar" class="cancela">Cancelar</button>
                <?if ($operacao == "editando") echo '<button type="excluir" class="excluir">Excluir</button>';?>
            </div>
        </form>
    </body>
</html>
