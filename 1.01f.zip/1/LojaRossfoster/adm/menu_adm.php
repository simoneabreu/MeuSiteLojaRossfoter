<html> 
     <body>
        <div>
            <a href='administrador/AdmAdministrador.php' target="JANELA_ADM_OPERACAO">
                <input type="button" value="Admin">
            </a>
            <a href='cliente/AdmCliente.php' target="JANELA_ADM_OPERACAO">
                <input type="button" value="Cliente">
            </a>
            <a href='produto/AdmProduto.php' target="JANELA_ADM_OPERACAO">
                <input type="button" value="Produto">
            </a> 
            <a href='pedido/AdmPedido.php' target="JANELA_ADM_OPERACAO">
                <input type="button" value="Pedido">
            </a>
            <!--a href='compra/AdmCompra.php.php' target="JANELA_ADM_OPERACAO">
                <input type="button" value="Compras">
            </a-->
        <div>
    </body>
</html> 
