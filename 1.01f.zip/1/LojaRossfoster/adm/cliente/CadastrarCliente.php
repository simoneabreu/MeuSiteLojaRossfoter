<?
session_start();
$idCliente = $_GET["id"];
if ($idCliente) {
    $operacao = "editando";
    $mysqli = new mysqli('LOCALHOST', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "SELECT * FROM Cliente WHERE idCliente = " . $idCliente;
    $result = $mysqli->query($query);
    if (!$result) {
        $mysqli->close();
        die("Erro na seleção de dados");
    }
    $row = $result->fetch_assoc();
} else {
    $operacao = "incluindo";
    $row = [];
    $row["nome"] = "";
    $row["sobrenome"] = "";
    $row["data_nascimento"] = "";
    $row["rg"] = "";
    $row["cpf"] = "";
    $row["rua"] = "";
    $row["numero"] = "";
    $row["complemento"] = "";
    $row["bairro"] = "";
    $row["cidade"] = "";
    $row["estado"] = "";
    $row["pais"] = "";
    $row["cep"] = "";
    $row["login"] = "";
    $row["senha"] = "";
}
?>
<html>
    <head>
        <title>Cadastro de Clientes</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    </head>
    <body>
        <form action="SalvarCliente.php" method="post" target="JANELA_ADM_CLIENTE_OPERACAO">
            <!-- DADOS PESSOAIS-->
            <div class="container">
                <h1><? if ($operacao == "editando") echo "Alterando"; else echo "Inserindo" ?> Cliente</h1>
                <input type="hidden" name="operacao" id="operacao" value="<?= $operacao?>">
                <? if ($operacao == "editando") echo '<input type="hidden" name="idCliente" id="idCliente" value="' . $idCliente . '">'; ?>
                <fieldset>
                    <legend>Dados Pessoais</legend>
                    <label for="nome">Nome: </label>
                    <input type="text" name="nome" id="nome" value="<?= $row["nome"]?>">
                    <label for="sobrenome">Sobrenome: </label>
                    <input type="text" name="sobrenome" id="sobrenome" value="<?= $row["sobrenome"]?>">
                    <p>
                        <label for="nascimento">Data nascimento:</label>
                        <input type="date" name="data_nascimento" id="data_nascimento" size="2" maxlength="2" value="dd">
                    </p>
                    <p>
                        <label for="rg">RG: </label>
                        <input type="text" name="rg" id="rg" value="<?= $row["rg"]?>" size="13" maxlength="13">
                        <label>CPF:</label>
                        <input type="text" name="cpf"  value="<?= $row["cpf"]?>" size="11" maxlength=11>
                    </p>
                </fieldset>
                <fieldset>
                    <legend>Endereço</legend>
                    <p>
                        <label for="rua">Rua, avenida, logradouro</label>
                        <input type="text" name="rua" id="rua" value="<?= $row["rua"]?>" >
                        <label for="numero">Nº</label>
                        <input type="text" name="numero" id="numero" value="<?= $row["numero"]?>" >
                        <label for="complemento">Complemento</label>
                        <input type="text" name="complemento" id="complemento" value="<?= $row["complemento"]?>" >
                        <label for="bairro">Bairro: </label>
                        <input type="text" name="bairro" id="bairro" value="<?= $row["bairro"]?>" >
                        </p>
                    <p>
                    <label for="cidade">Cidade: </label>
                    <input type="text" name="cidade" id="cidade" value="<?= $row["cidade"]?>" >
                    <label for="estado">Estado:</label>
                    <input type="text" name="estado" id="estado" value="<?= $row["estado"]?>" >
                    <label for="pais">País:</label>
                    <input type="text" name="pais" id="pais" value="<?= $row["pais"]?>" >
                    <label for="cep">CEP: </label>
                    <input type="text" name="cep" id="cep" size="8" maxlength="8" value="<?= $row["cep"]?>" >
                </p>
                </fieldset>
                <fieldset>
                    <legend>Dados de Login</legend>
                    <p>
                        <label for="login">Login de usuário: </label>
                        <input type="text" name="login" id="login" value="<?= $row["login"]?>" size="10" maxlength="10">
                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email" value="<?= $row["email"]?>" >
                    </p>
                    <p>
                        <label for="senha">Senha: </label>
                        <input type="password" name="senha" id="senha" value="" size="8" maxlength="8">
                        <label for="confirma_senha">Confirme a senha: </label>
                        <input type="password" name="confirma_senha" id="confirma_senha">
                        <input type="checkbox" checked="checked"> Lembrar senha
                    </p>
                    <p>
                        <label for="imagem_perfil">Imagem de perfil:</label>
                        <input type="file" name="imagem_perfil" id="imagem_perfil" value="">
                    </p>
                </fieldset>
                <br />
                <button type="submit" class="enviar">Salvar</button>
                <button type="cancelar" class="cancela">Cancelar</button>
                <?if ($operacao == "editando") echo '<button type="excluir" class="excluir">Excluir</button>';?>
            </div>
        </form>
    </body>
</html>
