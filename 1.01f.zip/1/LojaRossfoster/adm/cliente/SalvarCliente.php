<?php
session_start();
$erro = 0;
$operacao = $_POST['operacao'];
$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$data_nascimento = $_POST['data_nascimento'];
$rg = $_POST['rg'];
$cpf = $_POST['cpf'];
$rua = $_POST['rua'];
$numero = $_POST['numero'];
$numero = $_POST['complemento'];
$bairro = $_POST['bairro'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$pais = $_POST['pais'];
$cep = $_POST['cep'];
$email = $_POST['email'];
$login = $_POST['login'];
$senha = $_POST['senha'];
print_r($_POST);
if ($operacao == "incluindo") {
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "INSERT INTO " . 
        "Cliente (".
            "nome, sobrenome, data_nascimento, rg, cpf, " . 
            "rua, numero, complemento, bairro, cidade, estado, pais, cep, email, login, senha) " . 
        "VALUES (" . "'" . 
            $nome . "', '" . "', '" . $sobrenome . "', '" . $data_nascimento .
            $rg . "', '" . $cpf .  "', '" . $rua . "', '" . $numero . "', '" . $complemento . "', '" . 
            $bairro . "', '" . $cidade . "', '" . $estado .  "', '" . $pais . "', '" . $cep .
            $email . "," . "', '" . $login . "," . "', '" . $senha . ")";
    //echo $query;
    $result = $mysqli->query($query);
} else {
    $idCliente = $_POST['idCliente'];
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    if ($_POST['senha'] == "") {
        $strSenha = "";
    } else {
        $strSenha = "', senha = '" . $senha;
    }
    $query = "UPDATE Cliente " .
        "SET nome = '" . $nome . "', sobrenome = '" . $sobrenome . "', data_nascimento = '" . $data_nascimento  . "', " .
        "rg = '" . $rg . "', cpf = '" . $cpf . "', rua = '" . $rua . "', numero = '" . $numero . "', " . 
        "complemento = '" . $complemento . "', bairro = '" . $bairro . "', cidade = '" . $cidade . "', " . 
        "estado = '" . $estado . "', pais = '" . $pais . "', cep = '" . $cep . "', email = '" . $email . "', " . 
        "login = '" . $login . $strSenha . "' " .
        "WHERE idCliente = " . $idCliente;
    echo $query;
    die();
    $result = $mysqli->query($query);
}

echo '<script>';
echo 'window.open("AdmCliente.php","JANELA_ADM_OPERACAO");';
echo '</script>';

?>
