<?php

session_start();
require_once '../persistencia/clienteDAO.php';
require_once '../modelo/cliente.php';

if (!isset($_SESSION['cliente'])) {
    header('location: ./../index.php');
} else {
    $codigo = $_SESSION['cliente'];
    $cliente = ClienteDAO::buscarClientePorId($codigo);
    if ($cliente != NULL) {
        $data = explode("-", $cliente->getData_nascimento());
        ?>

    <!DOCTYPE html>
        <!--
        To change this license header, choose License Headers in Project Properties.
        To change this template file, choose Tools | Templates
        and open the template in the editor.
        -->
        <html>
            <head>
                <meta charset="UTF-8">
                <title>Edita cliente</title>
            </head>
            <body>
                <form action="controle/alteraCliente.php" method="post">
                    <p>
                        <label for="nome">Nome do cliente:</label>
                        <input type="text" name="nome" id="nome" required
                                value="<?=$cliente->getNome()?>">
                    </p>
                    <p>
                        <label for="sobrenome">Sobrenome:</label>
                        <input type="text" name="sobrenome" id="sobrenome" required
                                value="<?=$cliente->getSobrenome()?>">
                    </p>
                    <p>
                        <label for="nascimento">Dia de nascimento:</label>
                        <input type="date" name="dia_nascimento" id="dia_nascimento" required
                                value="<?=$data[2]?>">           
                    </p>
                    <p>
                        <label for="nascimento">Mês de nascimento:</label>
                        <input type="month" name="mes_nascimento" id="mes_nascimento" required
                                value="<?=$data[1]?>">
                    </p>
                    <p>
                        <label for="nascimento">Ano de nascimento:</label>
                        <input type="number" name="ano_nascimento" id="ano_nascimento" required
                                value="<?=$data[0]?>">
                    </p>
                    <p>
                        <label for="preco">RG:</label>
                        <input type="text" name="rg" id="rg" 
                               value="<?=$cliente->getRG()?>">
                    </p>
                    <p>
                        <label for="cpf">CPF:</label>
                        <input type="text" name="cpf" id="cpf" required
                                value="<?=$cliente->getCpf()?>">
                    </p>
                    <p>
                        <label for="rua">Endereço - Rua, avenida, logradouro:</label>
                        <input type="text" name="rua" id="rua" required
                                value="<?=$cliente->getEndereco()->getRua()?>">
                    </p>
                    <p>
                        <label for="numero">Número:</label>
                        <input type="text" name="numero" id="numero" required
                                value="<?=$cliente->getEndereco()->getNumero()?>">
                    </p>
                    <p>
                        <label for="bairro">Bairro:</label>
                        <input type="text" name="bairro" id="bairro" required
                                value="<?=$cliente->getEndereco()->getBairro()?>">
                    </p>
                    <p>
                        <label for="cidade">Cidade:</label>
                        <input type="text" name="cidade" id="cidade" required
                                value="<?=$cliente->getEndereco()->getCidade()?>">
                        
                        <label for="estado">Estado:</label>
                        <input type="text" name="estado" id="estado" required
                                value="<?=$cliente->getEndereco()->getEstado()?>">
      
                    </p>
                    <p>
                        <label for="cep">CEP:</label>
                        <input type="text" name="cep" id="cep" required
                                value="<?=$cliente->getEndereco()->getCep()?>">
                    </p>
                    <p>
                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email" required
                                value="<?=$cliente->getEmail()?>">
                    </p>
                    
                    <p>
                        <label for="login">Login:</label>
                        <input type="text" name="login" id="login" required
                                value="<?=$cliente->getLogin()?>">
                    </p>
                    <p>
                        <label for="senha">Senha:</label>
                        <input type="password" name="senha" id="senha" required
                                value="<?=$cliente->getSenha()?>">
                    </p>
                    <p>
                        <label for="confirma_senha">Confirma senha:</label>
                        <input type="password" name="confirma_senha" id="confirma_senha" required
                                value="<?=$cliente->getConfirma_senha()?>">
                    </p>
                    <input type="hidden" name="codigo" value="<?=$cliente->getCodigo()?>"
                    <p>
                        <button>Editar</button>
                    </p>
                </form>
            </body>
        </html>
        <?php
    }
}
?>
