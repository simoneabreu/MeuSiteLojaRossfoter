<?php
session_start();
if (isset($_SESSION['clientes'])) {
    $clientes = $_SESSION['clientes'];
} else {
    $clientes = array();
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Administrador</title>
        <style>
            @import "../../estilosCss/indexCliente.css";

            label{
                display: inline-block;
                width:50px;
            }
            table, th, td {
                border: 1px solid black;
            }   
        </style>
    </head>
    <body>

<table>
                        <tr>
                            <th>cliente</th>
                            <th>CPF</th>
                            <th>Ações</th>
                        </tr>
                        <?php
                        foreach ($clientes as $c) {
                            ?>
                            <tr>
                                <td><?= $c['nome'] ?></td>
                                <td><?= $c['cpf'] ?></td>
                                <td>
                                    <a href="../controle/excluirCliente.php?cpf=<?= $c['cpf'] ?>"

                                       onclick="return confirm('Deseja excluir')">
                                        Excluir</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
    </body>
</html>