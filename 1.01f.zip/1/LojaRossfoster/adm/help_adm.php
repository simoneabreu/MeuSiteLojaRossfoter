
<html>
      <head>
      </head>
      <body>
            <div>
                  <h1>Area do Administrador</h1>
                  <p>
                        <a href="help_adm.php?page=1">Help</a>
                  </p>
                  <p>
                        <a href="help_adm.php?page=2">About</a>
                  </p>
                  <p>
                        <a href="help_adm.php?page=3">Contact</a>
                  </p>
      </body>
</html>