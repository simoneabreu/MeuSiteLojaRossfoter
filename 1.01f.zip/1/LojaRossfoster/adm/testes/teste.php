<?php

require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/modelo/produto.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/persistencia/ProdutoDAO.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/persistencia/ClienteDAO.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/modelo/cliente.php";
session_start();

if (isset($_SESSION['cliente']) &&
        $_SESSION['nivel'] == Cliente::ADMINISTRADOR) {
    $produto = ProdutoDAO::todos();

    ?>

    <!--DOCTYPE html-->
    <html lang="pt-br">
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Excluir produtos</title>
            <link href="../estilosCss/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
            <div class="container theme-showcase" role="main">
                <div class="page-header">
                    <h1>Lista para exclusão de Produtos</h1>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Código</th>
                                    <th>Nome do Produto</th>
                                    <th>Ação</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php foreach ($produto as $p) { ?>
                                    <!--while($produtos = mysqli_fetch_assoc($produto))-->
                                    <tr>
                                        
                                        <td><?= $p->getCodigo() ?></td>
                                        <td><?= $p->getNome_produto() ?></td>

                                        <td>
                                          <!--  <button type="button" class="btn btn-xs btn-primary" data-toggle="modal" data-target="#myModal<?= $p->getCodigo() ?>">Visualizar</button>-->
                                            <!--  <button type="button" class="btn btn-xs btn-warning">Editar</button>-->
                                            
                                           <!--  <button type="button" class="btn btn-xs btn-danger">Apagar</button>-->
                                            <a href="../auxiliares/controle/excluirProduto.php?codigo=<?= $p->getCodigo() ?>"
                                            onclick="return confirm('Deseja excluir')">Excluir</a>
                                        </td>
                                    </tr>
                                <?php } ?>
                                <!-- Inicio Modal -->
                            <div class="modal fade" id="myModal<?= $p->getCodigo() ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title text-center" id="myModalLabel"><?= $p->getNome_produto() ?></h4>
                                        </div>
                                        <div class="modal-body">

                                            <p><?= $p->getCodigo() ?></p>
                                            <p><?= $p->getNome_produto() ?></p>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Fim Modal -->
                            <input type="voltar" type="button" value="Voltar" onClick="history.go(-1)"> 
                            </tbody>
                        </table>
                    </div>
                </div>		
            </div>

            <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
            <!-- Include all compiled plugins (below), or include individual files as needed -->
            <script src="../scriptsJs/bootstrap.min.js"></script>
        </body>
    </html>
    <?php

        

        }