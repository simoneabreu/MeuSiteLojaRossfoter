<?php

require_once $_SERVER['DOCUMENT_ROOT']."/trabalho/modelo/cliente.php";
require_once $_SERVER['DOCUMENT_ROOT']."/trabalho/persistencia/clienteDAO.php";



$login = $_POST['login'];
$senha = $_POST['senha'];

$cliente = ClienteDAO::logar($login, $senha);

//var_dump($cliente->getCodigo());

if($cliente !=null){ // cliente nulo
  
    session_start();
   
   $_SESSION['cliente'] = $cliente->getCodigo();
    
    $_SESSION['nivel'] = $cliente->getNivel();
    
    if($cliente->getNivel()==  Cliente::ADMINISTRADOR){
    
   header('location:../../auxiliares/administrador/index.php');
    }if ($cliente->getNivel()==  Cliente::CLIENTE){
      header('location:../../auxiliares/cliente/index.php');  
    }if ($cliente->getNivel()==  Cliente::CLIENTE_FORNECEDOR){
     header('location:../../auxiliares/clienteFornecedor/index.php'); 
   // header(' location:/trabalho/auxiliares/clienteFornecedor/index.php');
    }
   
}
 else {
   
  header('location: ../../index.php');
 }
?>

