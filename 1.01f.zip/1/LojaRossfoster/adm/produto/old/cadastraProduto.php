<?php

//session_start();
require_once $_SERVER['DOCUMENT_ROOT']."/trabalho/modelo/produto.php";
require_once $_SERVER['DOCUMENT_ROOT']."/trabalho/persistencia/produtoDAO.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/modelo/cliente.php";

if(isset($_SESSION['nivel']) && $_SESSION['nivel']== Cliente::CLIENTE_FORNECEDOR){
    
   // $codigo = $_POST['codigo'];
    $nome_produto = $_POST['nome_produto'];
    $descricao = $_POST['descricao'];
    $estoque = $_POST['estoque'];
    $preco = $_POST['preco'];
    $promocao = $_POST['promocao'];
    $custo = $_POST['custo'];
    $fornecedor = $_POST['fornecedor'];
    $foto = $_FILES['foto']; 
    
    $p = new Produto($nome_produto, $descricao, $estoque, $preco, $promocao, $custo, $fornecedor, $foto,'Produto');
    ProdutoDAO::cadastrar($p);
            

}
header("location: ../clienteFornecedor/index.php");
?>
