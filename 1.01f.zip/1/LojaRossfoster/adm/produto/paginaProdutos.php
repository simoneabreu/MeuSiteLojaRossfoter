<html>
    <head>

        <style type="text/css">
            @import "../estilosCss/paginaProdutos.css";
        </style>
    </head>

    <body>
        <div id="principal">
            <div id="topo">
            </div>
            <br>
            <div id="titulo"   align="center">
                <font face='Arial' size='4'>Confira abaixo, os produtos disponiveis no site:</font> 
            </div
            <br>
            <div id="figura2" >
                <?php
//PEGA A CHAVE DO ARRAY
                ?>
                <figure >
                    <center> <img src="../imagensProdutos/Malbec.png" width="180" height="180" ></center>
                     <h3> Malbec </h3> 
                    <figcaption> R$ 189,90</figcaption>                                      
                </figure>        
                <a href="#" class="botao" role="button">Comprar</a>
                <a href="detalhesDoProduto.php" class="botao" role="button">Detalhes</a>
                <?php
                ?>
            </div>
            <div id="figura2">
                <?php
//PEGA A CHAVE DO ARRAY
                ?>
                <figure>
                    <img src="../imagensProdutos/sabonete em barra.jpg" width="180" height="180" >
                <a href="#"> <h3> Sabonete em barra </h3></a>              
                <figcaption> R$ 29,90</figcaption>                                      
                </figure> 
               <a href="#" class="botao" role="button">Comprar</a>
                <a href="#" class="botao" role="button">Detalhes</a>
                <?php
                ?>
            </div>
<div id="figura2">
                <?php
//PEGA A CHAVE DO ARRAY
                ?>
                <figure>
                    <img src="/imaagensProdutos/sabonete liquido.png" width="180" height="180" >
                <a href="#"> <h3>  </h3></a>              
                <figcaption> R$ 40,99</figcaption>                                      
                </figure> 
               <a href="#" class="botao" role="button">Comprar</a>
                <a href="#" class="botao" role="button">Detalhes</a>
                <?php
                ?>
            </div>
<div id="figura2">
                <?php
//PEGA A CHAVE DO ARRAY
                ?>
                <figure>
                    <img src="../imagensProdutos/refil nativaSpa ameixa negra.png" width="180" height="180" >
                <a href="#"> <h3> Refil nativa Spa ameixa negra </h3></a>              
                <figcaption> R$ 78,99</figcaption>                                      
                </figure> 
               <a href="#" class="botao" role="button">Comprar</a>
                <a href="#" class="botao" role="button">Detalhes</a>
                <?php
                ?>
            </div>
            <div id="figura2">
                <?php
//PEGA A CHAVE DO ARRAY
                ?>
                <figure>
                    <img src="../imagensProdutos/combo nativa Spa ameixa.png" width="180" height="180" >
                <a href="#"> <h3> combo nativa spa de ameixa </h3></a>              
                <figcaption> R$ 109,90</figcaption>                                      
                </figure> 
               <a href="#" class="botao" role="button">Comprar</a>
                <a href="#" class="botao" role="button">Detalhes</a>
                <?php
                ?>
            </div>
            <div id="figura2">
                <?php
//PEGA A CHAVE DO ARRAY
                ?>
                <figure>
                    <img src="../imagensProdutos/mascara de cilios preta.jpg" width="180" height="180" >
                <a href="#"> <h3> Mascara de cilios preta </h3></a>              
                <figcaption> R$ 21,90</figcaption>                                      
                </figure> 
               <a href="#" class="botao" role="button">Comprar</a>
                <a href="#" class="botao" role="button">Detalhes</a>
                <?php
                ?>
            </div>
            <input class="voltar" type="button" value="Voltar" onClick="history.go(-1)"> 
</div>
        
</body>
</html>

<!--http://www.webmaster.pt/carrinho-compras-php-5462.html-->