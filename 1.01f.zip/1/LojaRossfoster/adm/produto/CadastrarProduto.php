<?php
//idProduto, nome_produto, custo, descricao, estoque, fornecedor, foto, preco, promocao
session_start();
$idProduto = $_GET["id"];
if ($idProduto) {
    $operacao = "editando";
    $mysqli = new mysqli('LOCALHOST', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "SELECT * FROM Produto WHERE idProduto = " . $idProduto;
    $result = $mysqli->query($query);
    if (!$result) {
        $mysqli->close();
        die("Erro na seleção de dados");
    }
    $row = $result->fetch_assoc();
} else {
    $operacao = "incluindo";
    $row["nome_produto"] = "";
    $row["descricao"] = "";
    $row["estoque"] = "";
    $row["preco"] = "";
    $row["custo"] = "";
    $row["promocao"] = "";
    $row["fornecedor"] = "";
    $row["foto"] = "";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
    </head>
    <body>
        <form action="SalvarProduto.php" target = "JANELA_ADM_PRODUTO_OPERACAO" method="post">
            <div class="container">
                <h1><? if ($operacao == "editando") echo "Alterando"; else echo "Inserindo" ?> Produto</h1>
                <input type="hidden" name="operacao" id="operacao" value="<?= $operacao?>">
                <? if ($operacao == "editando") echo '<input type="hidden" name="idProduto" id="idProduto" value="' . $idProduto . '">'; ?>
                <fieldset>
                    <legend>Insira os dados do produto</legend>
                    <p>
                        <label for="produto">Produto</label>
                        <input type="text" id="nome_produto" name="nome_produto" title="Preencha com o nome do produto." 
                            placeholder="Nome do produto" required value="<?= $row['nome_produto']?>">
                    </p>
                    <p>
                        <label for="descricao">Descrição</label> <br>
                        <textarea name="descricao" required value="" d="descricao" cols="30" rows="10" 
                        placeholder="Descrição do Produto"><?= $row['descricao']?></textarea>
                    </p>
                    <p>
                        <label for="estoque">Estoque</label>
                        <input type="text" name="estoque" id="estoque" placeholder="Quantidade em estoque" value="<?= $row['estoque']?>">
                    </p>
                </fieldset>
                <fieldset>
                    <legend>Financeiro</legend>
                    <p>
                        <label for="preco">Preço</label>
                        <input type="text" required name="preco" title="Preencha com o preço do produto." id="Preço"
                            placeholder="Preço do Produto" value="<?= $row['preco']?>">
                    </p>
                    <p>
                        <label for="promocao">Promoção</label>
                        <input type="text" name="promocao" id="promocao" placeholder="Promoção do Produto" value="<?= $row['promocao']?>">
                    </p>
                    <p>
                        <label for="custo">Custo</label>
                        <input type="text" name="custo" id="custo" placeholder="Custo do produto" value="<?= $row['custo']?>">
                    </p>
                    <p>
                        <label for="fornecedor">Fornecedor</label>
                        <input type="text" name="fornecedor" id="fornecedor" placeholder="Nome Fornecedor do Produto" value="<?= $row['fornecedor']?>">
                    </p>
                    <p>
                        <label for="foto">Foto</label>
                        <input type="text" name="foto" id="foto" required value="<?= $row['foto']?>" /> 
                    </p>
                    <input type="submit" class="enviar" name="Enviar" />
                </fieldset>
            </form>
        </div>
    </body>
</html>
