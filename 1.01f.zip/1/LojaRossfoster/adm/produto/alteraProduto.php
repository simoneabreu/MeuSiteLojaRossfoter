<?php

session_start();
require_once '../../persistencia/produtoDAO.php';
require_once '../../modelo/produto.php';

$erro = 1;

if(isset($_SESSION['cliente'])){
   
    $produto = time().$_FILES['foto']['name'];
    
    $nome_produto = $_POST['nome_produto'];
    $descricao = $_POST['descricao'];
    $estoque = $_POST['estoque'];
    $preco = $_POST['preco'];
    $promocao = $_POST['promocao'];
    $custo = $_POST['custo'];
    $fornecedor = $_POST['fornecedor'];
    $foto = ($_FILES['foto']['tmp_name']); //,"../imagensProduto/$Produto");
   $codigo = $_POST['codigo'];
    
    $p = new Produto($nome_produto,$descricao,$estoque,$preco,$promocao,$custo,$fornecedor,$foto,$codigo);
    if(ProdutoDAO::alterar($p)){
        $erro = 0;
    }
    else{
        $erro = 2;
    }
}
$_SESSION['erro_cadastro']=$erro;
header("location: ../index.php");
?>
    
    
    
    
    
    