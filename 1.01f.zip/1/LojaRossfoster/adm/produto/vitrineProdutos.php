<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Vitrine de produtos</title>
                <link href="../estilosCss/bootstrap.min.css" rel="stylesheet">
	</head>
	<body>
		<div class="container theme-showcase" role="main">
			<div class="page-header">
				<h1>Produtos</h1>
			</div>
			<div class="row">
				
					<div class="col-sm-6 col-md-4">
						<div class="thumbnail">
                                                    <img src="../imagensProdutos/Malbec.png" alt="...">
							<div class="caption text-center">
								<a href="#"> <h3> Malbec</h3></a>
								<p> <a href="#" class="btn btn-primary" role="button">Comprar</a> </p>
							</div>
						</div>
					</div>
				
			</div>
                    <div class="row">
				
					<div class="col-sm-6 col-md-4">
						<div class="thumbnail">
                                                    <img src="../imagensProdutos/mascara de cilios preta.jpg" alt="...">
							<div class="caption text-center">
								<a href="#"> <h3> Mascara de cilios preta </h3></a>
								<p> <a href="#" class="btn btn-primary" role="button">Comprar</a> </p>
							</div>
						</div>
					</div>
				
			</div>
                    <div class="row">
				
					<div class="col-sm-6 col-md-4">
						<div class="thumbnail">
                                                    <img src="../imagensProdutos/sabonete liquido.png" alt="...">
							<div class="caption text-center">
								<a href="#"> <h3> Sabonete liquido 200ml </h3></a>
								<p> <a href="#" class="btn btn-primary" role="button">Comprar</a> </p>
							</div>
						</div>
					</div>
				
			</div>
		</div>
		
		
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
                <script src="../scriptsJs/bootstrap.min.js"></script>
	</body>
</html>