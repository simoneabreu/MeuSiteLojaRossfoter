<?php

session_start();
require_once '../persistencia/produtoDAO.php';
require_once '../modelo/produto.php';

if (!isset($_SESSION['cliente'])) {
    header('location: index.php');
} else {
   
    $codigo = $_SESSION['cliente'];
    $produto = ProdutoDAO::buscarProdutoPorId($codigo);
    if ($produto != NULL) {
        ?>

    <!DOCTYPE html>
        <!--
        To change this license header, choose License Headers in Project Properties.
        To change this template file, choose Tools | Templates
        and open the template in the editor.
        -->
        <html>
            <head>
                <meta charset="UTF-8">
                <title></title>
            </head>
            <body>
                <form action="controle/alteraProduto.php" method="post">
                    <p>
                        <label for="nome_produto">Nome do produto:</label>
                        <input type="text" name="nome_produto" id="nome_produto" required
                                value="<?=$produto->getNome_produto()?>">
                    </p>
                    <p>
                        <label for="descricao">Descrição do produto:</label>
                        <input type="text" name="descricao" id="descricao" required
                                value="<?=$produto->getDescricao()?>">
                    </p>
                    <p>
                        <label for="estoque">Estoque:</label>
                        <input type="text" name="estoque" id="estoque" required
                                value="<?=$produto->getEstoque()?>">
                    </p>
                    <p>
                        <label for="preco">Preço:</label>
                        <input type="text" name="preco" id="preco" 
                               value="<?=$produto->getPreco()?>">
                    </p>
                    <p>
                        <label for="promocao">Promoção:</label>
                        <input type="text" name="promocao" id="promocao" required
                                value="<?=$produto->getPromocao()?>">
                    </p>
                    <p>
                        <label for="custo">Custo do produto:</label>
                        <input type="text" name="custo" id="custo" required
                                value="<?=$produto->getCusto()?>">
                    </p>
                    <p>
                        <label for="fornecedor">Fornecedor do produto:</label>
                        <input type="text" name="fornecedor" id="fornecedor" required
                                value="<?=$produto->getFornecedor()?>">
                    </p>
                    <p>
                        <label for="foto">Foto do produto:</label>
                        <input type="file" name="foto" id="foto" accept=".jpg" required
                                value="<?=$produto->getFoto()?>">
                    </p>
                   
                    <p>
                        <button>Editar</button>
                    </p>
                </form>
            </body>
        </html>
        <?php
    }
}
?>

