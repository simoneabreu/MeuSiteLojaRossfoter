<?session_start();?>
<html>
    <head>
        <!-- Bootstrap core CSS -->
        <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"> Loja Rossfoter</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <ul class="navbar-nav me-auto mb-2 mb-md-0">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="index.php" target="JANELA_INDEX">Início</a>
                            </li>
                            <?
                                if ($_SESSION['idCliente']) {
                                   echo '<li class="nav-item">';
                                   echo '<a class="nav-link"  href="cli/cli.php" target="JANELA_OPERACAO">Área do Cliente</a>';
                                   echo '</li>';
                                }
                            ?>
                            <?
                                if ($_SESSION['idAdmin']) {
                                   echo '<li class="nav-item">';
                                   echo '<a class="nav-link" href="adm/adm.php" target="JANELA_OPERACAO">Área do Administrador</a>';
                                   echo '</li>';
                                }
                            ?>
                        </ul>
                        <?
                        if ($_SESSION['idCliente'] || $_SESSION['idAdmin']) {
                            $idLogin = "sair";
                            $botaoLogin = "Sair";
                        } else {
                            $idLogin = "entrar";
                            $botaoLogin = "Entrar";
                        }
                        ?>
                        <form action="login.php" method="post" target="JANELA_OPERACAO">
                            <input type="submit" id="<?= $idLogin?>" name="<?= $idLogin?>" value="<?= $botaoLogin?>">
                        </form>
                    </div>
                </div>
            </nav>
        </header>
        <div>        
            <a href='index.php' target="JANELA_INDEX">
                <input type="button" value="Inicio">
            </a>
            <a href='cli/cli.php' target="JANELA_OPERACAO">
                <input type="button" value="Área Cliente">
            </a>
            <a href='adm/adm.php' target="JANELA_OPERACAO">
                <input type="button" value="Área Administrador">
            </a>
        <div>
    </body>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script></html>
