<?
session_start();

$mysqli = new mysqli('LOCALHOST', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');

if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);

$query = "SELECT * FROM Cliente";

$result = $mysqli->query($query);

if (!$result) {
    $mysqli->close();
    die("Erro na seleção de dados");
}//fechando a minha conexão

?>
<!--DOCTYPE html-->
<html lang="pt-br">
    <body>
        <div class="container theme-showcase" role="main">
            <div class="row">
                <div class="col-md-12">
                    <table class="table">
                        <!--thead>
                            <tr>
                                <th>Nome</th>
                            </tr>
                        </thead-->
                        <tbody>                                
                            <?php 
                                if ($result) {
                                    //echo "#: ".$result->num_rows;
                                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                                    //print_r($rows);
                                    $len = count($rows);
                                    $i = 0;
                                    //foreach ($rows as $row) {
                                    while ($i < $len) {
                                        $row = $rows[$i];
                                        $i = $i + 1;
                                        echo "<tr>";
                                        echo "<td>";
                                        echo "<a href='CadastrarCliente.php?idCliente=".$row["idCliente"]."' target='JANELA_ADM_CLIENTE_OPERACAO'>";
                                        echo $row["nome"];
                                        echo "</a>";
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                }?>
                        </tbody>
                    </table>
                </div>
            </div>		
        </div>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="../scriptsJs/bootstrap.min.js"></script>
    </body>
</html>
<?php
    $result->free_result();
    $mysqli->close();
?>
