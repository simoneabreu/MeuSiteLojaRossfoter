<? ?>
<html> 
     <body>
        <div>
            <a href='IncluirCliente.php' target="JANELA_ADM_CLIENTE_OPERACAO">
                <input type="button" value="Incluir">
            </a>
        <div>
    </body>
</html>
<? ?>
