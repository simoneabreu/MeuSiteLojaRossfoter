<?php

require_once '../modelo/cliente.php';
require_once '../modelo/produto.php';

session_start();
if (isset($_SESSION['clientes'])) {
    $clientes = $_SESSION['clientes'];
} else {
    $produto = array();
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Administrador</title>
        <style>
            @import "../../estilosCss/indexCliente.css";

            label{
                display: inline-block;
                width:50px;
            }
            table, th, td {
                border: 1px solid black;
            }   
        </style>
    </head>
    <body>

<table>
                        <tr>
                            <th>produto</th>
                            <th>codigo</th>
                            <th>Ações</th>
                        </tr>
                        <?php
                        foreach ($produto as $p) {
                            ?>
                            <tr>
                                <td><?= $p['nome_produto'] ?></td>
                                <td><?= $p->getCodigo() ?></td>
                                <td>
                                    <a href="../auxiliares/controle/excluirProduto.php?codigo=<?= $p['codigo'] ?>"

                                       onclick="return confirm('Deseja excluir')">Excluir</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
    </body>
</html>
