<?php
session_start();
$erro = 0;
$operacao = $_POST['operacao'];
$nome_produto = $_POST['nome_produto'];
$descricao = $_POST['descricao'];
$estoque = $_POST['estoque'];
$preco = $_POST['preco'];
$custo = $_POST['custo'];
$promocao = $_POST['promocao'];
$fornecedor = $_POST['fornecedor'];
$foto = $_POST['foto'];
//idProduto, nome_produto, custo, descricao, estoque, fornecedor, foto, preco, promocao
if ($operacao == "incluindo") {
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "INSERT INTO Produto (nome_produto, descricao, estoque, preco, custo, promocao, fornecedor, foto) " . 
        "VALUES ('" . $nome_produto . "', '" . $descricao . "', " . $estoque . 
        ", " . $preco . ", " . $custo . ", " . $promocao . ", '" . $fornecedor . "', '" . $foto . "')";
    //echo $query;
    $result = $mysqli->query($query);
} else {
    $idProduto = $_POST['idProduto'];
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "UPDATE Produto SET nome_produto = '" . $nome_produto . 
        "', descricao = '" . $descricao . "', estoque = " . $estoque . ", preco = " . $preco . 
        ", custo = " . $custo . ", promocao = '" . $promocao . 
        "', fornecedor = '" . $fornecedor . "', foto = '" . $foto . "' WHERE idProduto = " . $idProduto;
    echo ($query);
    $result = $mysqli->query($query);
}
echo '<script>';
echo 'window.open("AdmProduto.php","JANELA_ADM_OPERACAO");';
echo '</script>';
//echo "<a href='AdmProduto.php' target='JANELA_ADM_OPERACAO'>Continuar</a>";
?>
