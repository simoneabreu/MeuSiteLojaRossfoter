

<html>
    <title>Detalhes do produto</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <head>

        <style type="text/css">
            @import "../estilosCss/detalhesProduto.css";
       </style>
    </head>
    <body>
        <div id="principal" class="w3-panel w3-pale-yellow w3-leftbar w3-bottombar w3-border-red w3-border">

            <div id="titulo"   align="center">
                <h1>Detalhes do produto</h1> 
            </div>
            <figure>
                <img src="../imagensProdutos/Base em Pó Mineral Bege Medio.png" alt="Monitor" width="300" height="225" />

                <h3>Maquiagem</h3>
                <strong>Fornecedor: </strong> O Boticario.<br>

                <strong>Valor: </strong> R$ 99,99 <br>

                <strong>Descrição:</strong> Base em pó especial para peles sensíveis.<br> 
               
            </figure>
            <a href="#" class="botao" role="button">Comprar</a>
          <!--  <a href="../index.php" class="botao-voltar" role="button">Voltar</a>-->
            <input class="botao-voltar" type="button" value="Voltar" onClick="history.go(-1)"> 
        </div>

    </body>
</html>
<!--http://www.webmaster.pt/pagina-produtos-php-jquery-json-595.html-->
<!--https://www.caelum.com.br/apostila-vraptor-hibernate/criando-o-carrinho-de-compras/#13-5-exercicios-->