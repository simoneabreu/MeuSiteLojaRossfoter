<?php

require_once '../../modelo/cliente.php';
require_once '../../persistencia/produtoDAO.php';


session_start();
if (isset($_SESSION['cliente'])) {
   // $clientes = unserialize($_SESSION['cliente']);
    if ($clientes->getNivel() == Cliente::ADMINISTRADOR || $clientes->getNivel() == Cliente::CLIENTE_FORNECEDOR) {
        $codigo = $_GET['codigo'];
        ProdutoDAO::excluir($codigo);
    }
}
header('location: ../index.php');
?>

