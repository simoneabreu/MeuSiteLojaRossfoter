<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Sobre</title>
        <style> @import "../estilosCss/sobre.css";
        </style>
    </head>
    <body> 
        <div id="pagina">
        <img src="../imagens/logon.png">
        <h1 id="titulo"> Loja Rossfoter <h1/>
            <div id="sobre"> 
                <p>
                    Bem-vindo à <strong>Loja Rossfoter</strong>, sua loja virtual de perfumaria, cuidados para o corpo e maquiagens.
                </p>
                <p>
                    Confira nossas promoções.<br>
                    Receba informações sobre nossos lançamentos por email.<br>
                    Navegue por todos nossos produtos com catálogo.<br>
                    Compre sem sair de casa.<br>
                   A Loja Rossfoter traz para você comodidade, praticidade aliado a satisfação.
                </p>
                
                  <input class="voltar" type="button" value="Voltar" onClick="history.go(-1)">  
                <div id="rodape">

                    &copy;2021 Copyright Loja Rossfoter
                </div>
            </div>
        </div>
            <?php
            // put your code here
            ?>
        
        
    </body>
</html>
