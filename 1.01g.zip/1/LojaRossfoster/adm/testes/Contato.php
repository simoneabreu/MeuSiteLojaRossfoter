
<!--DOCTYPE html-->
    <html lang="pt-br">
        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Listar produtos</title>
<form action="envia.php" name="envia" id="envia" method="post">
    
    <style>
        @import "../auxiliares/../estilosCss/contato.css";
    </style>
</head>
<body>
    <div class="container">
       
        <fieldset>
            <legend><b>Entre em contato</b></legend>
            <p>
                <label for="nome">Nome</label>
                <input type="text" name="nome" id="nome">
            </p>
            <label for="email">Email</label>
            <input type="email" name="email" id="email">
            <p>
                <label for="telefone">Telefone</label>
                <input type="tel" name="telefone" id="telefone">
            </p>
            <p>
                <label for="assunto">Assunto</label>
                <input type="text" name="assunto" id="assunto">
            </p>
            <p>
                <label for="mensagem">Mensagem</label> <br>
                <textarea name="mensagem" id="mensagem" cols="30" rows="10"></textarea>
            </p>
            <p>
                <input type="submit" name="enviar" id="enviar" value="Enviar">
                <input type="voltar" type="button" value="Voltar" onClick="history.go(-1)"> 
            </p>

        </fieldset>
    </div>
</form>
    </body>
</html>
<!--http://www.drcode.com.br/php/como-fazer-envio-de-formulario-de-contato-com-php-->