
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/modelo/produto.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/persistencia/ProdutoDAO.php";
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/persistencia/ClienteDAO.php";
session_start();

if (isset($_SESSION['nivel']) &&
        $_SESSION['nivel'] == Cliente::ADMINISTRADOR || $_SESSION['nivel'] == Cliente::CLIENTE_FORNECEDOR) {
    $produto = ProdutoDAO::todos();
   // if (isset($_POST['produto'])) {
 //     $clientes = ClienteDAO::buscarPorProduto($_POST['produto']);
  // } else {
   //    $produto = null;
   // }
    ?>

<form action="index.php?p=3" method="post">
    <label for="produto">Produtos:</label>
    <select name="produto" id="produto" required="">
        <option value="">Escolha um produto</option>
        <?php foreach ($produto as $p){ ?>
        <option value="<?=$p->getCodigo()?>">
                <?=$p->getCodigo()?>
        </option>
        <?php }  ?>
    </select>
    <button>Exibir Lista</button>
</form>

<?php  } ?>

<!--Read more: http://www.linhadecodigo.com.br/artigo/3511/criando-um-filtro-automatico-nas-colunas-de-uma-tabela-html.aspx#ixzz4lg72QRzc-->

<!-- esse ---http://webdevacademy.com.br/tutoriais/crud-com-bootstrap-3-parte5/-->