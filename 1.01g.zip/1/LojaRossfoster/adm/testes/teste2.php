<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title> Carrinho de Compras </title>
        <link rel="stylesheet" href="css/framework.css">
        <link rel="stylesheet" href="css/estilo.css">
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
        <style>
            section {width: 80%; height: auto; margin: 5% 10%;}
            section header{width: 89.1%; height: auto; margin: 1% 5%}
            section article{width: 25%; height: auto; margin: 1% 2%}
            section .first{margin-left: 5%;}
            section .car_show:hover{background-color: #900;}
            section article table{width: 775px; height: auto; margin: 1% 0%}
            section article td{padding: 3% 1%}

            input[type=number]{width: 50px; }
            input[type=text]{width: 400px; padding: 2% 5%; }
            button{padding: 2% 5%; }

            *{padding: 0; margin: 0; border: 0; font-size: 1em; font-family: 'Lato';}<!--frame-->

            .font-text-light{font-size: 1em;}
            .font-text-light-extra{font-size: 1.2em;}
            .font-text-hard-two{font-size: 2em;}
            .font-weight-heavy{font-weight:bold;}

            .text-center{text-align:center;}
            .text-justify{text-align:justify;}
            .text-left{text-align:left;}
            .text-right{text-align:right;}

            .float-left{float: left;}
            .float-right{float: right;}

            .color-white{color: #fff;}
            .color-DarkOrange{color: #1A242E;}
            .color-dark-full{color: #1A242E;}
            .color-dark{color: orangered;}


            .bgcolor-salmon{background-color: salmon;}
            .link-bgcolor-salmon{padding: 3% 8%;  background-color:salmon;}
            .bgcolor-green-dark{background-color:#009f6a;}
            .link-bgcolor-green-dark-b{padding: 1% 2%; background-color:#009f6a;}
            .bgcolor-red{background-color: #d4383a;}
            .link-bgcolor-red{padding: 0.5% 2%; background-color: #d4383a;}
            .bgcolor-red-dark{background-color: #b32500;}
            .link-bgcolor-red-dark-b{padding: 1% 2%; background-color: #b71c1c;}
            .link-bgcolor-white-dark-b{padding: 1% 2%; background-color: #eee;}
            .link-bgcolor-DarkOrange{padding: 1% 2%;  background-color: darkorange;}
            .bgcolor-white{background-color: #fff;}
            .bgcolor-white-dark{background-color: #eee;}
            .bgcolor-orangeRed{background-color:orangered;}
            .bgcolor-dark-full{background-color:  #1A242E;}
        </style>
    </head>

    <body>
        <section>
            <header>
                <p class="text-right ">
                    <a href="index.php" class="color-white bgcolor-red font-text-light font-weight-heavy car_show">Produtos</a></p><br>
                <h1 class="color-white text-center font-text-hard-two font-weight-heavy link-bgcolor-DarkOrange">CARRINHO</h1>
            </header>

            <article class="first float-left">
                <table>

                    <tr>
                        <td class="bgcolor-salmon">
                            <p class="text-center color-dark-full font-text-light"><?= 'Nome do Produto' ?></p>
                            <input type="text" name="produto" value="<?= 'Nome do Produto' ?>" style="display:none" ></td>
                    <form method="post">
                        <td class="bgcolor-salmon"> 
                            <p class="text-center color-dark-full font-text-light">
                                <input type="number" name="id"  value="<?= 'Id do Produto' ?>" style="display:none;">
                                <input type="number" name="quantidade"  value="<?= '1' ?>" class="text-center">&nbsp;
                                <button class="color-white link-bgcolor-green-dark-b" name="alterar" value="Alterar"> Alterar</button>
                            </p>

                        </td>

                        <td class="bgcolor-salmon">
                            <p class="text-center color-dark-full font-text-light">R$ <?= number_format('0.00', 2, ',', '.'); ?></p></td>
                        <input type="text" name="preco" value="<?= '0.00' ?>" style="display:none" >
                    </form>

                    <td class="bgcolor-salmon"><p class="text-center font-text-light">
                            <a href="excluir-produto.php?ref=<?= 'id do produto' ?>" class="color-dark-full">Excluir Produto</a>
                        </p>
                    </td>
                    </tr>

                    <tr>
                        <td colspan="3" class="bgcolor-orangeRed text-right color-white">
                            <form method="post">
                                <input type="text" name="cupom" placeholder="Se você tem um cupom de desconto ou vale. Coloque aqui...">
                                <button name="descontar" value="Descontar">Descontar</button>
                            </form>
                        </td>
                    </tr>

                    <tr>
                        <td colspan="1" class="orangeRed text-right color-white">Total da Compra: R$ <?= number_format('0.00', 2, ',', '.'); ?></td>
                    </tr>
                    <tr>
                        <td colspan="4" class="bgcolor-orangeRed text-right color-white">
                            <a href="finalizar-pedido.php?total = <?= '0.00' ?>" class="link-bgcolor-red-dark-b text-right color-white">Finalizar Pedido</a>
                        </td>
                    </tr>
                </table>
            </article>
        </section>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    </body>
</html>


