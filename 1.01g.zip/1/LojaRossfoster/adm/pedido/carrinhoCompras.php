<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title> Carrinho de Compras </title>
       
        <style>
            div{
    border: solid 1px #00C0C0;
}
.principal{
    width: 700px;
    min-height: 600px;
    margin:auto;
}
.produto{
    float: right;
    background-color: red;
}
h1{
    text-align: center;
    background-color:  #FF8C00;
}
.n_produto{
  background-color: #FFEBCD;  
}
.alterar{
  background-color: #FFEBCD;  
}
.preco{
  background-color: #FFEBCD;  
}
.exclui{
  background-color: #FF8C00;  
}
.finaliza{
    float: right;
    background-color:  red;
}
.descontar{
  background-color: #FFEBCD;   
}
.total{
  background-color: #FFEBCD;   
}
        </style>
    </head>

    <body>
        <div class="principal">
                <p class="produto"><a href="index.php">Produtos</a></p><br>
                <h1>Sua compras</h1>
                <table>
                <tr>
                        <td class="n_produto">
                            <p><?= 'Nome do Produto' ?></p>
                            <input type="text" name="produto" value="<?= 'Nome do Produto' ?>" style="display:none" ></td>
                        <td class="alterar"> 
                            <p class="">
                                <input type="number" name="codigo"  value="<?= 'Codigo do Produto' ?>" style="display:none;">
                                <input type="number" name="quantidade"  value="<?= '1' ?>" class="text-center">&nbsp;
                                <button class="" name="alterar" value="Alterar"> Alterar</button>
                            </p>

                        </td>
                        <td class="preco">
                            <p class="">R$ <?= number_format('0.00', 2, ',', '.'); ?></p></td>
                        <input type="text" name="preco" value="<?= '0.00' ?>" style="display:none" >
                        <td class="exclui">
                            <p class="">
                            <a href="excluir-produto.php?ref=<?= 'id do produto' ?>" class="">Excluir Produto</a>
                        </p>
                    </td>
                    </tr>
                              <tr>
                        <td colspan="3" class="descontar">
                            
                                <input type="text" name="cupom" placeholder="Se você tem um cupom de desconto ou vale. Coloque aqui...">
                                <button name="descontar" value="Descontar">Descontar</button>
                              </td>
                    </tr>

                    <tr>
                        <td colspan="1" class="total">Total da Compra: R$ <?= number_format('0.00', 2, ',', '.'); ?></td>
                    </tr>
                    <tr>
                        <td colspan="4" class="finaliza">
                            <a href="finalizar-pedido.php?total = <?= '0.00' ?>" class="">Finalizar Pedido</a>
                        </td>
                    </tr>
                </table>
             </div>
    </body>
</html>




