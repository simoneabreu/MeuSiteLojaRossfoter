<?php
session_start();
$erro = 0;
$operacao = $_POST['operacao'];
$nome = $_POST['nome'];
$login = $_POST['login'];
$senha = $_POST['senha'];
$email = $_POST['email'];
if ($operacao == "incluindo") {
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "INSERT INTO Admin (nome,login,email,senha) " . 
        "VALUES ('" . $nome . "', '" . $login . "', '" . $email . "', '" . md5($senha) . "')";
    echo $query;
    $result = $mysqli->query($query);
} else {
    $idAdmin = $_POST['idAdmin'];
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "UPDATE Admin SET nome = '" . $nome . "', login = '" . $login . "', senha = '" . md5($senha) . 
        "', email = '" . $semail . "' WHERE idAdmin = " . $idAdmin;
    $result = $mysqli->query($query);
}
echo '<script>';
echo 'window.open("AdmAdministrador.php","JANELA_ADM_OPERACAO");';
echo '</script>';
?>
