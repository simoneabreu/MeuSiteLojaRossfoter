<?php
session_start();
$erro = 0;
$idAdmin = $_GET['idAdmin'];
if ($idAdmin) {
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "DELETE FROM Admin WHERE idAdmin = " . $idAdmin;
    //echo $query;
    //die();
    $result = $mysqli->query($query);
}
echo '<script>';
echo 'window.open("AdmAdministrador.php","JANELA_ADM_OPERACAO");';
echo '</script>';
?>
