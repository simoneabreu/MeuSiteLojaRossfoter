<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/modelo/cliente.php";
//require_once $_SERVER['DOCUMENT_ROOT'] . "/trabalho/auxiliares/CadastraCliente.php";

session_start();
//if (!isset($_SESSION['usuario']) || $_SESSION['usuario'] != "Cliente") {
  //  header("location: ../index.php");
//} else {
 if(isset($_SESSION['nivel']) && $_SESSION['nivel']== Cliente::CLIENTE){
    ?>
    <!DOCTYPE html>
    
    <html>
        <head>
            <meta charset="UTF-8">
            <title>Cliente</title>
            <style>
                @import "../../estilosCss/indexCliente.css";
            </style>
        </head>
        <body>
            <div id="pagina">
                <div id="topo">
                    <div id="sacola">
                        <image src="../../imagens/cesta.png" width="30">
                        <p>Nenhum item no carrinho
                        </p>
                    </div>
                </div>

                <div id="busca">
                    <p>Busca</p>
                    <form>
                        <input type="search">
                        <input type="image" src="../../imagens/busca.png" class="lupa">
                    </form>

                    <p class="direita"><a href="../controle/sair.php">Logout</a></p>
                </div>
                <div id="centro">

                    <nav id="menu_vertical">
                        <ul>
                            <li><a href="index.php?p">Inicio</a></li>
                            <li><a href="../paginaProdutos.php?">Produto</a></li>
                            <li><a href="../CadastraCliente.php?">CadastroCliente</a></li> 
                            <li><a href="../editarCliente.php?">Altera dados do Cliente</a></li>  
                            
                        </ul>
                    </nav>
                    <div class="slide1">
                        <h2 class="center">Promoções</h2>
                        <img class="slide" src="../../imagensProdutos/Base em Pó Mineral Bege Medio.png" width="350">
                        <img class="slide" src="../../imagensProdutos/colonia egeo.jpg" width="350">
                        <img class="slide" src="../../imagensProdutos/ofertas.jpg" width="350">

                        <button class="button black display-left" onclick="plusDivs(-1)">&#10094;</button>
                        <button class="button black display-right" onclick="plusDivs(1)">&#10095;</button>

                    </div>
                </div>
                <div id="box_esquerda">
                    <section class="painel novidades">
                        <h2>Novidades</h2>
                        <ol>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/sabonete em barra.jpg" width="110">
                                        <figcaption>Sabonete em barra- R$ 29,90</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/sabonete liquido.png" width="110">
                                        <figcaption>Sabonete liquido - R$ 40,99</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/refil nativaSpa ameixa negra.png" width="110">
                                        <figcaption>Refil Nativa Spa ameixa - R$ 78,99</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/Malbec.png" width="110" height="70">
                                        <figcaption>Malbec - R$ 189,90</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/combo nativa Spa ameixa.png" width="110">
                                        <figcaption>Combo nativa Spa ameixa - R$ 109,90</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/mascara de cilios preta.jpg" width="110">
                                        <figcaption>Mascara de cilios preta - R$ 21,90</figcaption>
                                    </figure>
                                </a>
                            </li>
                        </ol>
                    </section>
                    <section class="painel mais-vendidos">
                        <h2>Mais Vendidos</h2>
                        <ol>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/Lily.jpg" width="110">
                                        <figcaption>Lily - R$ 236,99</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/Palette Multifuncional.jpg" width="110">
                                        <figcaption>Palette Multifuncional - R$ 78,99</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/Batom.jpg" width="110">
                                        <figcaption>Batom- R$ 21,99</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/Primer Facial.png" width="110">
                                        <figcaption>Primer Facial - R$ 69,99</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/Pincel Kabuki Retrátil Rose.png" width="110">
                                        <figcaption>Pincel Kabuki Retrátil Rose- R$ 69,99</figcaption>
                                    </figure>
                                </a>
                            </li>
                            <li>
                                <a href="../../imagensProdutos/">
                                    <figure>
                                        <img src="../../imagensProdutos/Base em Pó Mineral Bege Medio.png" width="110">
                                        <figcaption> Base em Pó Mineral Bege Medio- R$ 99,99</figcaption>
                                    </figure>
                                </a>
                            </li> 

                        </ol>
                    </section>

                </div>
                
                <div id="rodape">
                    <ul class="social">
                        <li class="facebook"><a href="http://facebook.com/facebook">Facebook</a></li>
                       
                        <li><a href="http://google.com/googleplus">Google+</a></li>
                    </ul>
                    <p><b>@Copryght - Loja Rossfoter - 2021</b></p>
                </div>
            </div>
            <script src="../../scriptsJs/Scripts.js"></script>
        </body>
    </html>
    
}
<?php } ?>
