<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
        <meta name="generator" content="Hugo 0.88.1">
        <title> Loja Rossfoter</title>

        <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/carousel/">



        <!-- Bootstrap core CSS -->
        <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">

        <style>
            .bd-placeholder-img {
                font-size: 1.125rem;
                text-anchor: middle;
                -webkit-user-select: none;
                -moz-user-select: none;
                user-select: none;
            }

            @media (min-width: 768px) {
                .bd-placeholder-img-lg {
                    font-size: 3.5rem;
                }
            }
        </style>


        <!-- Custom styles for this template -->
        <link href="carousel.css" rel="stylesheet">
    </head>
    <body>

        <header>
            <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"> Loja Rossfoter</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarCollapse">
                        <ul class="navbar-nav me-auto mb-2 mb-md-0">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Area do Cliente</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link">Area administrativa</a>
                            </li>
                        </ul>
                        <form class="d-flex">
                            
                            <a href="login.php" class="btn btn-outline-success" type="submit">Login</a>
                        </form>
                    </div>
                </div>
            </nav>
        </header>

        <main>

            <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></svg>

                        <div class="container">
                            <div class="carousel-caption img-fluid">
                                <h1>Sabonete</h1>


                                <figure>
                                    <img src="./imagensProduto/sabonete em barra.jpg" width="300">
                                    <figcaption>Sabonete- R$ 29,90</figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">

                        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></svg>

                        <div class="container">
                            <div class="carousel-caption img-fluid">
                                <h1>Sabonete liquido</h1>


                                <figure>
                                    <img src="./imagensProdutos/sabonete liquido.png" width="300">
                                    <figcaption>Sabonete liquido- R$ 40,99</figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></svg>

                        <div class="container">
                            <div class="carousel-caption img-fluid">
                                <h1>refil nativaSpa ameixa negra</h1>


                                <figure>
                                    <img src="./imagensProdutos/refil nativaSpa ameixa negra.png" width="300">
                                    <figcaption>refil nativaSpa ameixa negra- R$ 78,99</figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                   
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>


            <!-- Marketing messaging and featurettes
            ================================================== -->
            <!-- Wrap the rest of the page in another container to center all the content. -->
            <h1 class="text-center">Promoções</h1>
            <hr class="featurette-divider">
            <div class="container marketing">

                <!-- Three columns of text below the carousel -->

                <!-- START THE FEATURETTES -->



                <div class="row featurette">
                    <div class="col-md-7">
                        <h2 class="featurette-heading">Malbec- R$ 189,90 <span class="text-muted"></span></h2>
                        <p class="lead">Inspirado pela cor azul, Malbec traz uma exclusiva combinação para voce</p>
                    </div>
                    <div class="col-md-5">
                        <figure>
                            <img src="./imagensProdutos/Malbec.png" width="500">

                        </figure>
                    </div>
                </div>

                <hr class="featurette-divider">
                <div class="row featurette">
                    <div class="col-md-7 ">
                        <h2 class="featurette-heading">Combo nativa Spa ameixa - R$ 109,90 <span class="text-muted"></span></h2>
                        <p class="lead">Presente Nativa SPA Ameixa </p>
                    </div>
                    <div class="col-md-5">
                        <figure>
                            <img src="./imagensProdutos/combo nativa Spa ameixa.png" width="500">

                        </figure>
                    </div>
                </div>

                <hr class="featurette-divider">


                <!-- /END THE FEATURETTES -->

            </div><!-- /.container -->


            <!-- FOOTER -->
            <footer class="container">
                <p class="float-end"><a href="#">Voltar ao topo</a></p>
                <p>&copy; 2021 - Loja Virtual Rossfoter. &middot;</p>
            </footer>
        </main>


        <script src="assets/dist/js/bootstrap.bundle.min.js"></script>


    </body>
</html>
