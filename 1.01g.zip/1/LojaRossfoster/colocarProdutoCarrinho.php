<?php
session_start();
if (!$_SESSION['idCliente']) {
    echo "Faça login";
    echo "<a href='login.php' target='JANELA_INDEX'>Continuar</a>";
}
$erro = 0;
$operacao = $_GET['operacao'];
$idProduto = $_GET['idProduto'];
if ($operacao == "incluindo") {
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    if ($_SESSION['idPedido']) {
        $idPedido = $_SESSION['idPedido'];
    } else {
        $query = "INSERT INTO Pedido (idCliente) VALUES (".$_SESSION['idCliente'].")";
        //echo $query;
        $result = $mysqli->query($query);
        $idPedido = $mysqli->insert_id;
        $_SESSION['idPedido'] = $idPedido;
    }
    $query = "INSERT INTO ItemPedido (idPedido,idProduto,qtdProduto) VALUES (" . $idPedido . "," . $idProduto . ",1)";
    //echo $query;
    $result = $mysqli->query($query);
} else {
    $idCliente = $_POST['idCliente'];
    $mysqli = new mysqli('localhost', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
    if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
    $query = "UPDATE Cliente SET nome = '" . $nome . "', sobrenome = '" . $sobrenome . 
        "', rg = '" . $rg . "', cpf = '" . $cpf . "' WHERE idCliente = " . $idCliente;
    $result = $mysqli->query($query);
}
?>
<script>
    window.open('index.php','JANELA_INDEX');
</script>
