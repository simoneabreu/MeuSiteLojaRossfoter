<?
    session_start();
    if ($_POST['sair']) {
        $_SESSION['idAdmin'] = 0;
        $_SESSION['idCliente'] = 0;
        $_SESSION['idPedido'] = 0;
        echo '<script>';
        echo 'window.open("index.php","JANELA_INDEX");';
        echo '</script>';
        die();
    } else {
        $login = $_POST['login'];
        if ($login) {
            $senha = $_POST['senha'];
            if ($senha) {
                $mysqli = new mysqli('LOCALHOST', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');
                if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);
                $query = "SELECT * FROM Cliente WHERE login = '" . $login . "'";
                $result = $mysqli->query($query);
                if (!$result) {
                    $mysqli->close();
                    die("Erro na seleção de dados");
                }
                if ($result->num_rows > 0) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $row = $rows[0];
                    //x echo md5($senha); die();
                    if (($row['login'] == $login) && ($row['senha'] ==  md5($senha))) {
                        $_SESSION['idCliente'] = $row['idCliente'];
                        echo '<script>';
                        echo 'window.open("index.php","JANELA_INDEX");';
                        echo '</script>';
                        die();
                    }
                } else {
                    $query = "SELECT * FROM Admin WHERE login = '" . $login . "'";
                    $result = $mysqli->query($query);
                    if (!$result) {
                        $mysqli->close();
                        die("Erro na seleção de dados");
                    }
                }
                if ($result->num_rows > 0) {
                    $rows = $result->fetch_all(MYSQLI_ASSOC);
                    $row = $rows[0];
                    if (($row['login'] == $login) && ($row['senha'] == md5($senha))) {
                        $_SESSION['idAdmin'] = $row['idAdmin'];
                        echo '<script>';
                        echo 'window.open("index.php","JANELA_INDEX");';
                        echo '</script>';
                        die();
                    }
                }
            }
        }
    }
?>

<!doctype html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <title>Login</title>
        <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/sign-in/">
        <!-- Bootstrap core CSS -->
        <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            .bd-placeholder-img {
                font-size: 1.125rem;
                text-anchor: middle;
                -webkit-user-select: none;
                -moz-user-select: none;
                user-select: none;
            }
            @media (min-width: 768px) {
                .bd-placeholder-img-lg {
                    font-size: 3.5rem;
                }
            }
        </style>
        <!-- Custom styles for this template -->
        <link href="signin.css" rel="stylesheet">
    </head>
    <body class="text-center">
        <main class="form-signin">
            <form action="login.php" method="post" target="JANELA_OPERACAO">
                <img class="mb-4" src="assets/brand/bootstrap-logo.svg" alt="" width="72" height="57">
                <h1 class="h3 mb-3 fw-normal">Por Favor faça o Login</h1>
                <fieldset>
                    <legend>Login e Senha</legend>
                    <div class="form-floating">
                        <input id="login" name="login" type="text" class="form-control">
                    </div>
                    <div class="form-floating">
                        <input id="senha" name="senha" type="password" class="form-control">
                    </div>
                    <div class="checkbox mb-3">
                        <label>
                            <input type="checkbox" value="remember-me"> Salvar sessão
                        </label>
                    </div>
                </fieldset>
                <button class="w-100 btn btn-lg btn-primary" type="submit">Entrar</button>
                <p class="mt-5 mb-3 text-muted">Direito Autorais - Loja Rossfoter - 2021</p>
            </form>
          </main>
    </body>
</html>
