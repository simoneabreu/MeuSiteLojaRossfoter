<?session_start();?>
<html>
     <body>
        <div>
            <!--a href="CliCadastrar.php' target="JANELA_CLI_OPERACAO">
                <input type="button" value="Cadastrar">
            </a>
            <a href='CarrinhoCompras.php' target="JANELA_CLI_OPERACAO">
                <input type="button" value="Carrinho">
            </a-->
            <?
            if ($_SESSION['idPedido']) {
                echo '<a href="CliItemPedido.php" target="JANELA_CLI_OPERACAO">';
                echo '<input type="button" value="Pedidos">';
                echo '</a>';
            }
            ?>
        <div>
    </body>
</html> 
