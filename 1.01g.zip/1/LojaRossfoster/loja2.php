<?
session_start();

$mysqli = new mysqli('LOCALHOST', 'u576255937_simone', 'Simone1986', 'u576255937_lojarossfoster');

if ($mysqli->connect_errno) die("Erro de Conexão:" . $mysqli->connect_error);

$query = "SELECT * FROM Produto";

$result = $mysqli->query($query);

if (!$result) {
    $mysqli->close();
    die("Erro na seleção de dados");
}//fechando a minha conexão

function buscarProdutos($result) {
    $produtos = $result->fetch_all(MYSQLI_ASSOC);
    return $produtos;
}

function mostrarBotoes($produtos){
    $str = '';//inicializando
    //echo "estou aki 2";
    // echo "#: ".$result->num_rows;
    //print_r($rows);
    $len = count($produtos);
    $i = 0;
    //  echo $len.' '.$i;
    //foreach ($rows as $row) {
    while ($i < $len) {//enquanto o meu contador for menor que o nro de linhas
        $i = $i + 1;
        if ($i==1) {
            $ativo =  'class="active"';
        } else {
            $ativo = '';
        }
        $str .= ' <button type="button" data-bs-target="#myCarousel" ';
        $str .= 'data-bs-slide-to="'.($i-1).'" '.$ativo.' aria-current="true" ';
        $str .= 'aria-label="Slide '.$i.'"></button>'; //fazendo concatenção e colocando a sequencia do slides do bd 
    }
    return $str;
}

function mostrarProdutos($produtos) {
   // echo "to aqui";
    $str = '';//inicializando
    //echo "estou aki 2";
    //echo "#: ".$result->num_rows;
    //print_r($rows);
    $len = count($produtos);
    $i = 0;
    //echo $len.' '.$i;
    //foreach ($rows as $row) {
    while ($i < $len) {//enquanto o meu contador for menor que o nro de linhas
        $row = $produtos[$i];
        $i = $i + 1;
        if ($i==1) {
            $ativo = 'active';
        } else {
            $ativo = '';
        }
        $str .= '<div class="carousel-item '.$ativo.'">';// concatenação de uma serie de string 
        $str .= '<svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#777"/></svg>';
        
        $str .= '<div  class="container">';
        $str .= '<div class="carousel-caption img-fluid">';
        $str .='<h1>'.$row["descricao"].'</h1>'; 
        $str .='<figure>';
        $str .='<img src="'.$row["foto"].'" width="300">';
        $str .='<figcaption>R$ '.$row["preco"].'</figcaption>';
        if ($_SESSION['idCliente']) {
            $str .= '<a href="colocarProdutoCarrinho.php?operacao=incluindo&idProduto='.$row["idProduto"].'"><input type="button" value="Comprar"></a>';
        }
        $str .=' </figure>';
        $str .='</div>';
        $str .='</div>';
        $str .='</div>';
    }
    return $str;
}   
         
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
        <meta name="generator" content="Hugo 0.88.1">
        <title> Loja Rossfoter</title>

        <link rel="canonical" href="https://getbootstrap.com/docs/5.1/examples/carousel/">
        <!-- Bootstrap core CSS -->
        <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            .bd-placeholder-img {
                font-size: 1.125rem;
                text-anchor: middle;
                -webkit-user-select: none;
                -moz-user-select: none;
                user-select: none;
            }

            @media (min-width: 768px) {
                .bd-placeholder-img-lg {
                    font-size: 3.5rem;
                }
            }
        </style>
        <!-- Custom styles for this template -->
        <link href="carousel.css" rel="stylesheet">
    </head>
    <body>
        <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
            <? $produtos = buscarProdutos($result); ?>
            <?= mostrarBotoes($produtos);?>
            </div>
            <div class="carousel-inner">
                <?= mostrarProdutos($produtos); //chamando a função e ?>      
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        <!-- Marketing messaging and featurettes
        ================================================== -->
        <!-- Wrap the rest of the page in another container to center all the content. -->
        <h1 class="text-center">Promoções</h1>
        <hr class="featurette-divider">
        <div class="container marketing">
            <!-- Three columns of text below the carousel -->
            <!-- START THE FEATURETTES -->
            <div class="row featurette">
                <div class="col-md-7">
                    <h2 class="featurette-heading">Malbec- R$ 189,90 <span class="text-muted"></span></h2>
                    <p class="lead">Inspirado pela cor azul, Malbec traz uma exclusiva combinação para voce</p>
                </div>
                <div class="col-md-5">
                    <figure>
                        <img src="imagensProdutos/malbec.png" width="500">

                    </figure>
                </div>
            </div>

            <hr class="featurette-divider">
            <div class="row featurette">
                <div class="col-md-7 ">
                    <h2 class="featurette-heading">Combo nativa Spa ameixa - R$ 109,90 <span class="text-muted"></span></h2>
                    <p class="lead">Presente Nativa SPA Ameixa </p>
                </div>
                <div class="col-md-5">
                    <figure>
                        <img src="imagensProdutos/combo_nativa_spa_ameixa.png" width="500">

                    </figure>
                </div>
            </div>

            <hr class="featurette-divider">


            <!-- /END THE FEATURETTES -->

        </div><!-- /.container -->


        <!-- FOOTER -->
        <footer class="container">
            <p class="float-end"><a href="#">Voltar ao topo</a></p>
            <p>&copy; 2021 - Loja Virtual Rossfoter. &middot;</p>
        </footer>
        <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
