class x {
    constructor() {
        this.a = 1;
    }
    beforeExecute() {
        this.a = 2;
    }
    afterExecute() {    
        this.a = 3;
    }
}

class y extends x {
    constructor() {
        super();
        this.b = 1;
    }   
